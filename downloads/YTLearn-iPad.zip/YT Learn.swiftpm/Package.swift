// swift-tools-version: 5.8
// Swift Playgrounds app project (iPad / Mac). Open this folder in Swift Playgrounds and tap Run.
import PackageDescription
import AppleProductTypes

let package = Package(
    name: "YT Learn",
    platforms: [
        .iOS("16.0")
    ],
    products: [
        .iOSApplication(
            name: "YT Learn",
            targets: ["AppModule"],
            bundleIdentifier: "local.ytlearn.playgrounds",
            displayVersion: "3.0",
            bundleVersion: "1",
            appIcon: .placeholder(icon: .play),
            accentColor: .presetColor(.blue),
            supportedDeviceFamilies: [
                .pad,
                .phone
            ],
            supportedInterfaceOrientations: [
                .portrait,
                .landscapeRight,
                .landscapeLeft,
                .portraitUpsideDown(.when(deviceFamilies: [.pad]))
            ],
            capabilities: [
                .microphone(purposeString: "The microphone hears your voice commands (\"hi bro\", \"shut up\") and your questions for the AI."),
                .speechRecognition(purposeString: "Speech recognition turns your voice commands and questions into text.")
            ]
        )
    ],
    targets: [
        .executableTarget(
            name: "AppModule",
            path: ".",
            resources: [
                .process("Resources")
            ]
        )
    ]
)
