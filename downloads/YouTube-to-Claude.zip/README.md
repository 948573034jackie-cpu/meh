# YouTube to Claude / ChatGPT (Chrome extension)

Learn English from YouTube videos with Claude (claude.ai) or ChatGPT (chatgpt.com), both in Chrome.

**Pick a mode** at the top of the popup: *Claude* or *ChatGPT*. Everything goes to that chat.

**Button:** *Send this video to …* sends the video link + full transcript (as a text file).

**When you pause the video** (Space, click, or the pause button):
1. The last **~25 seconds** of speech appear over the video as complete sentences — **only the subtitles, nothing else** on the screen. Each full sentence has its own line; tiny phrases stay with a neighbouring sentence.
2. The video plays that part again **once at normal speed**, then stops.
3. **In the last second of the replay**, the text you just read is sent to your chat (the first time for a video, with the link + full transcript too), with one plain instruction: explain this part like an English teacher, then repeat the sentences — directly, no greeting, titles, headings or bullet points.
4. Talk about it with Claude/ChatGPT. When you are ready, say **“let's go”**, or press **Space**, the **play arrow**, click the video, or press **Enter**: the video jumps back to the start of that part and plays on through the rest of the video.

**Popup settings:** replay on/off, **text size slider (1–10 in quarter steps, 6 = medium, 10 = the biggest)**, send the transcript on/off, “let's go” voice command on/off.

## My tutor (v3.1): your own AI teacher, with your own API key
The **My tutor** button on the video bar turns it on (Claude / ChatGPT turns off: one voice at a time).
1. Click ⚙ on the Dream panel (or the extension icon → Dream Tutor settings) → API keys: paste your Claude and/or
   OpenAI key → Save. (OpenAI gives the natural voice and the live voice call.)
2. Open a YouTube video with subtitles. The AI first makes complete sentences and marks what is hard for you.
3. At a hard word, phrase or sentence the video stops, the page shows the last 30 s, the word is said 3 times.
   Say **"I know"** (K) or **"I don't know"** (D); silence = it explains. Then a moment to ask; quiet = on.
4. Pause = the part again + explained. ← = the last sentence. "bye bye" / Esc = stop the AI, play again.
   Space = pause the teacher. Shift+T = talk. Shift+L = listening mode. [ ] = text size.

## Install
1. Download and unzip https://github.com/948573034jackie-cpu/meh/releases/download/claudesnap-latest/YouTube-to-Claude.zip
2. `chrome://extensions` → Developer mode → Load unpacked → choose the unzipped folder. (Updating: copy the new files over the old folder, then press the reload arrow.)
3. Pin the extension. Refresh your YouTube tab and your Claude/ChatGPT tab.
4. The first time you use “let's go”, Chrome asks to allow the **microphone for youtube.com** — click Allow.

## Text size is stable
The size is tied to the video player's *current* size by the browser itself (CSS container units), so it can never get stuck huge or tiny: fullscreen and theater mode make it scale up and back down smoothly, there is a hard limit (14–120 px), and your slider setting is kept.

## Sending (how it presses Send)
It types the message, then clicks Send. If the message is still in the box it presses Enter (the send key in ChatGPT), and if the page ignores that, it sends a real Enter key press through Chrome itself (this is why the extension asks for the *debugger* permission; Chrome may flash a "started debugging this browser" bar for a moment). After every try it checks that the message really left the box.

## Limits
- Needs a video with captions (typed or auto-generated) or YouTube's “Show transcript”.
- Use a normal text chat (not voice mode) in Claude/ChatGPT — voice mode has no text box to type into. The bottom of the video shows ✓ or ✗ with the reason.
- “let's go” uses Chrome's speech recognition (needs internet). With speakers, the AI saying “let's go” could trigger it; headphones avoid this. Space / Enter / the play arrow always work.
- The subtitles are loaded in the background as soon as the video opens, so the first pause is instant. The popup's “Last:” line shows how many seconds each send took.
- Ads are ignored. Only youtube.com/watch pages.

## Picture for Claude, and no repeated words
* With **Claude** selected, every pause sends the words **and a picture of the video** (the frame where you paused, without the subtitles on top). **ChatGPT** gets the words only. You can turn the picture off in the extension window ("Claude only: also send a picture…").
* YouTube's automatic subtitles repeat the end of one line at the start of the next line. The extension now removes these repeats, so every sentence appears once.

## Subtitles: six ways, saved, and your own file
The extension tries these in order and uses the first one that looks right (its times must fit the length of the video, and a long video must be fully covered):
1. a subtitle file you loaded yourself (.srt / .vtt / .txt) in the extension window,
2. the copy saved the last time you watched this video (opens instantly, also in a new window),
3. the video's caption file, 4. the same list the YouTube phone app uses, 5. YouTube's transcript service,
6. the subtitles the player itself downloads (it switches CC on for a moment and back off), 7. the "Show transcript" panel (it waits until a long panel has filled up).
Every message carries the timeline ("Paused at 12:34. This part runs from 12:10 to 12:35"). Tick "Attach the full subtitles on every pause" if you want the whole file each time.

## Small bar under the video
Claude | ChatGPT | Send video ▸ sits right under the player. It sends the link + the full subtitles (with timeline).

## Claude voice mode
Voice mode has no text box, so only a picture can be sent. In that case the extension sends one picture that contains the time, the sentences **and** the question, and Claude answers by voice.

## Version 2.1: the full transcript goes only once, when you press a button
* Under the video there are two buttons: **ChatGPT** and **Claude**. Red = off, green = on.
* Press one (it turns green): the link + the **full transcript** go to that chat **once**. The other one turns red.
* From then on, every pause sends **only the part you paused at** (about 30 seconds, complete sentences, one per line on the screen), never the whole transcript again.
* Press the green one again: it turns red and pauses are not sent anywhere (the subtitles still show on the video).

## Version 2.2: "hi bro" / "shut up" and talk mode
* The microphone listens while you watch (allow the microphone for youtube.com the first time).
* Say **"hi bro"**: the video stops and that part (~30 s) is sent, exactly like pausing it. If the video itself says "bro" at that moment, it is ignored.
* **Talk mode** (on by default): the AI's answer is read aloud by Chrome, and whatever you say while the video is stopped goes into the chat as your question (as text). This is a real conversation that works with Claude **and** ChatGPT, and Claude always gets text.
* Say **"shut up"**: the voice stops at once, the AI tabs are muted (also Claude's own voice mode), and the video keeps playing from where it stopped. "hi bro" un-mutes them.
* Use headphones, so the microphone does not hear the video or the answer.

## Version 2.3: text into a voice call, "shut up" replays the part, picture after 1 s
* **Voice call with Claude (or ChatGPT):** the call screen has no text box. When a pause is sent, the extension steps out of the call for a moment (presses "end voice"), types the text + picture into the normal box and sends it, reads the answer aloud (talk mode), then presses the voice button again, so you are back in the call and Claude knows the text. If the page's buttons cannot be found, the picture with the words is sent instead, and the status lists the buttons it saw.
* **"shut up"** now goes back to the start of the paused part (~30 s of complete sentences), plays it again, and keeps playing to the end.
* The picture for Claude is taken **1 second** after the pause.

## Version 2.4: Claude HEARS the part in a voice call; off = plain YouTube
* **Voice call:** when you pause (or say "hi bro"), the ~30 s part replays, and its own sound is played **into the call's microphone line**. You and Claude hear it at the same time; Claude then answers by voice. The mixing happens inside Chrome after echo cancellation, so Chrome cannot silence it. The picture is sent 1 second after the pause. (Reload the Claude tab once after installing, before you start the call.)
* **Both buttons red (off):** the extension does nothing. Pausing is a normal YouTube pause: no subtitle screen, no replay, no microphone, no sending.

## Version 2.5: no more "repeating a few seconds"
* The microphone keeps one growing sentence while the video talks ("shut up and then the speaker says …"). Every update still contained "shut up", so the video jumped back again and again. Now each command acts **once** per sentence and the listener starts fresh.
* "shut up" (or pressing play after the part) goes back to the start of that part (~30 s, complete sentences) **once**, and plays on to the end of the video.
